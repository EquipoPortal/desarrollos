<?php
/*
Plugin Name: Árbol de Todas las categorías y Entradas con sus etiquetas asignadas
Description: Un plugin mejorado para mostrar un árbol con la estructura de categorías y las entradas que contiene cada una, además de abrir las entradas en nuevas pestañas.
Version: 2.8
Author: Equipo de la DGE Gob.de Mendoza
*/

// Función para cargar FontAwesome localmente.
function cargar_font_awesome() {
    wp_enqueue_style('font-awesome', plugin_dir_url(__FILE__) . 'font-awesome/css/font-awesome.min.css');
}
add_action('wp_enqueue_scripts', 'cargar_font_awesome');

// Función para obtener el árbol de categorías y entradas con iconos de FontAwesome.
function obtener_arbol_categorias_entradas() {
    // Obtener todas las categorías.
    $categorias = get_categories(array(
        'orderby' => 'name',
        'order'   => 'ASC'
    ));

    // Verificar si hay categorías.
    if ($categorias) {
        $output = '<ul class="arbol-categorias">';
        foreach ($categorias as $categoria) {
            // Obtener las entradas de la categoría.
            $entradas = get_posts(array(
                'numberposts' => -1,
                'category' => $categoria->term_id,
            ));

            // Determinar el nivel de la categoría.
            $nivel_categoria = obtener_nivel_categoria($categoria->term_id);
            $icono_color = obtener_color_icono($nivel_categoria);

            // Construir la entrada de categoría con iconos.
            $output .= '<li class="nivel-' . $nivel_categoria . '" data-categoria-id="' . $categoria->term_id . '">';
            $output .= '<i class="fa fa-folder ' . $icono_color . '"></i> <span class="categoria-principal">' . $categoria->name . ' (' . count($entradas) . ')</span>';

            // Si hay entradas en esta categoría principal, mostrarlas.
            if ($entradas) {
                $output .= '<ul class="entradas" style="display: none;">'; // Ocultar entradas por defecto.
                foreach ($entradas as $entrada) {
                    $output .= '<li><i class="fa fa-file"></i> <a href="' . get_permalink($entrada->ID) . '" target="_blank">' . $entrada->post_title . '</a>';

                    // Obtener y mostrar las etiquetas de la entrada.
                    $etiquetas = get_the_tags($entrada->ID);
                    if ($etiquetas) {
                        $output .= '<div class="etiquetas">';
                        foreach ($etiquetas as $etiqueta) {
                            $clase_etiqueta = ($etiqueta->name == 'Noticias') ? 'etiqueta-noticias' : 'etiqueta-normal';
                            $output .= '<span class="' . $clase_etiqueta . '">' . $etiqueta->name . '</span> ';
                        }
                        $output .= '</div>';
                    }

                    $output .= '</li>';
                }
                $output .= '</ul>';
            }

            // Si hay subcategorías, mostrarlas.
            $subcategorias = get_categories(array(
                'orderby' => 'name',
                'order'   => 'ASC',
                'parent'  => $categoria->term_id
            ));
            if ($subcategorias) {
                $output .= '<ul class="subcategorias">'; // No mostrar subcategorías por defecto.
                foreach ($subcategorias as $subcategoria) {
                    // Obtener el color del icono de la subcategoría.
                    $nivel_subcategoria = obtener_nivel_categoria($subcategoria->term_id);
                    $icono_color_subcategoria = obtener_color_icono($nivel_subcategoria);

                    // Obtener las entradas de la subcategoría.
                    $entradas_subcategoria = get_posts(array(
                        'numberposts' => -1,
                        'category' => $subcategoria->term_id,
                    ));

                    $output .= '<li class="nivel-' . $nivel_subcategoria . '" data-categoria-id="' . $subcategoria->term_id . '">';
                    $output .= '<i class="fa fa-folder ' . $icono_color_subcategoria . '"></i> <span class="subcategoria">' . $subcategoria->name . ' (' . count($entradas_subcategoria) . ')</span>';

                    // Si hay entradas en esta subcategoría, mostrarlas.
                    if ($entradas_subcategoria) {
                        $output .= '<ul class="entradas" style="display: none;">';
                        foreach ($entradas_subcategoria as $entrada) {
                            $output .= '<li><i class="fa fa-file"></i> <a href="' . get_permalink($entrada->ID) . '" target="_blank">' . $entrada->post_title . '</a>';

                            // Obtener y mostrar las etiquetas de la entrada.
                            $etiquetas = get_the_tags($entrada->ID);
                            if ($etiquetas) {
                                $output .= '<div class="etiquetas">';
                                foreach ($etiquetas as $etiqueta) {
                                    $clase_etiqueta = ($etiqueta->name == 'Noticias') ? 'etiqueta-noticias' : 'etiqueta-normal';
                                    $output .= '<span class="' . $clase_etiqueta . '">' . $etiqueta->name . '</span> ';
                                }
                                $output .= '</div>';
                            }

                            $output .= '</li>';
                        }
                        $output .= '</ul>';
                    }

                    $output .= '</li>';
                }
                $output .= '</ul>';
            }

            $output .= '</li>';
        }
        $output .= '</ul>';
    } else {
        $output = 'No se encontraron categorías.';
    }

    return $output;
}

// Función para obtener el nivel de la categoría en la jerarquía.
function obtener_nivel_categoria($categoria_id) {
    $nivel = 0;
    $categoria_actual = get_category($categoria_id);
    while ($categoria_actual->parent != 0) {
        $nivel++;
        $categoria_actual = get_category($categoria_actual->parent);
    }
    return $nivel;
}

// Función para obtener el color del icono según el nivel de la categoría.
function obtener_color_icono($nivel) {
    switch ($nivel) {
        case 0:
            return 'color-0'; // Rojo
            break;
        case 1:
            return 'color-1'; // Verde
            break;
        case 2:
            return 'color-2'; // Azul
            break;
        case 3:
            return 'color-3'; // Amarillo
            break;
        default:
            return ''; // Blanco
            break;
    }
}

// Shortcode para mostrar el árbol de categorías y entradas.
function shortcode_arbol_categorias_entradas() {
    $output = '<div class="arbol-categorias-container">' . obtener_arbol_categorias_entradas() . '</div>';
    return $output;
}
add_shortcode('arbol_categorias_entradas', 'shortcode_arbol_categorias_entradas');

// Agregar scripts y estilos para el árbol de categorías.
function agregar_scripts_estilos_arbol() {
    wp_enqueue_script('arbol-categorias-js', plugin_dir_url(__FILE__) . 'arbol-categorias.js', array('jquery'), null, true);
    wp_enqueue_style('arbol-categorias-css', plugin_dir_url(__FILE__) . 'arbol-categorias.css');
}
add_action('wp_enqueue_scripts', 'agregar_scripts_estilos_arbol');

// Agregar estilos para las etiquetas.
function agregar_estilos_etiquetas() {
    echo '<style>
        .etiquetas {
            margin-top: 5px;
        }
        .etiqueta-normal {
            background-color: #ddd;
            border-radius: 3px;
            padding: 2px 5px;
            margin-right: 5px;
        }
        .etiqueta-noticias {
            background-color: #32CD32; /* Verde claro fluor */
            border-radius: 3px;
            padding: 2px 5px;
            margin-right: 5px;
        }
    </style>';
}
add_action('wp_head', 'agregar_estilos_etiquetas');

// Función para mostrar la tabla de información de categorías y entradas.
function mostrar_tabla_informacion_categorias_entradas() {
    $cantidad_categorias = wp_count_terms('category');
    $cantidad_entradas = wp_count_posts('post');

    $tabla = '<table>';
    $tabla .= '<tr><th colspan="2">Información de Categorías y Entradas</th></tr>';
    $tabla .= '<tr><td>Categorías</td><td>' . $cantidad_categorias . '</td></tr>';
    $tabla .= '<tr><td>Entradas</td><td>' . $cantidad_entradas->publish . '</td></tr>';
    $tabla .= '</table>';

    return $tabla;
}
add_shortcode('informacion_categorias_entradas', 'mostrar_tabla_informacion_categorias_entradas');
?>


NECESITO QUE ESTE PLUGIN SEA modificado para que cumpla la funcion solamente con estas  categorias:  

5536
1589
5676
1019
4162
687
1020
1811
4622
780
2453
424
5659
5658
578
575
576
577
3013
1207
2010
4439
574
3752
872
690
686
685
688
683
689
684
427
871
849
692
876
944
945
5759
3131
5729
5422
5368
875
3266
6
